/* 
 * File:   main.cpp
 * Author: YOUR NAME HERE
 * Created on DATE AND TIME HERE
 * Purpose:  Convert a number to English check amount
 */

#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    unsigned short number;

    //Input or initialize values Here
    cout<<"Input an integer [1-3000] convert to an English Check value."<<endl;
    cin>>number;

    //Calculate the 1000's, 100's, 10's and 1's
    string arrayNumbers[] = {"One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"};
    string arrayNumbersTens[] = {"Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"};
    int thousands = number / 1000;
    if(thousands > 0){
        cout << arrayNumbers[thousands - 1] << " Thousand ";
    }
    number %= 1000;

    int hundreds = number / 100;
    if(hundreds > 0){
        cout << arrayNumbers[hundreds - 1] << " Hundred ";
    }
    number %= 100;
    int tens = number / 10;
    if(tens > 1){
        cout << arrayNumbersTens[tens - 2] << " ";
        number %= 10;
    }
    else if(tens == 1){
        cout << arrayNumbers[number - 1];
        number %= 10;
    }
    if(number > 0){
        cout << arrayNumbers[number - 1] << " ";
    }

    //Output the check value

    cout<<"and no/100's Dollars"<<endl;

    //Exit
    return 0;
}