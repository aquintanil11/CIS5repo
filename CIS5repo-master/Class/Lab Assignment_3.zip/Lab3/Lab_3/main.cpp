/* 
 * File:   main.cpp
 * Author: Antonio Quintanilla
 *Purpose: Calculate the percentage Gas Tax on a gallon of gas, 
 * and the profit made from a gallon of gas given
 * Created on January 16, 2019, 11:33 AM
 */

#include <iostream>
#include <iomanip>

using namespace std;

int main() 
{
    float ex_tax,       // Excise Tax Per Gallon
            sales_tax,  // Sales tax (Percentage)
            ctrade_fee, // Cap and trade fee on a tax per gallon
            fex_tax,    // Federal excise tax
            oc_profit,  // Oil Company Profit (Percentage)
            cost_gas,   // Cost of gas on last fill up
            gas_profit, //Profit that gas company receives
            sum_taxes;  //The sum of all taxes.
    
            ex_tax=.39;
            ctrade_fee=.10;
            fex_tax=.184;
                    
        cout << "Oil Comp. Profit vs. Taxes"<< endl;  
        cout << "Input the cost of gas per gallon in your last fill up."<< endl;
        cin >> cost_gas;
        
        sales_tax=.08*cost_gas;
        oc_profit=.065*cost_gas;
        gas_profit=cost_gas-(ex_tax+sales_tax+ctrade_fee+fex_tax+oc_profit);
        sum_taxes= (ex_tax+sales_tax+ctrade_fee+fex_tax);
                
        cout.setf(ios::fixed);
        cout.setf(ios::showpoint);
        cout.precision(2);
        
        cout << endl << "Gas Comnpany Profit = $" << setw(6) << gas_profit<< endl;
        cout << "Government Taxes = $" << setw(6)<< sum_taxes;
    
    
    return 0;
}

