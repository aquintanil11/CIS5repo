/* 
 * File:   main.cpp
 * Author: Antonio Quintanilla
 * Created on January 14, 2019, 3:44 PM
 * Purpose:  To calculate the military budget as a  
 *         percentage of the federal budget
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main() 
    {
    //Set the random number seed
    
    //Declare Variables
    float milBdgt,fedBdgt,mlPrcnt;

    milBdgt=7.0e11f;    //Military Budget = 700 Billion   

    fedBdgt=4.1e12f;    //Federal Budget  = 4.1 Trillion
    //Initialize or input i.e. set variable values
    //Map inputs -> outputs
            mlPrcnt=(milBdgt/fedBdgt)*100;
    //Display the outputs
            cout << "The military budget is " << mlPrcnt << "%" << endl;
            cout << " of the federal budget." << endl;
    //Exit stage right or left!
    return 0;
}

