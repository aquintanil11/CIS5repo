/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Antonio Quintanilla
 *
 * Created on January 15, 2019, 8:00 PM
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

int main(int argc, char** argv) {
    //Declare variables
    const int SIZE=15;
    char n1[SIZE],n2[SIZE],n3[SIZE];
    unsigned short t1,t2,t3;
    
    //Input the data
    cout<<"Race Ranking Program"<<endl;
    cout<<"Input 3 Runners\n";
    cout<<"Their names, then their times"<<endl;
    cin>>n1>>t1;
    cin>>n2>>t2;
    cin>>n3>>t3;
    
    //Output as test
    if(t1<t2&&t2<t3){
        cout<<n1<<"\t"<<setw(3)<<t1<<endl;
        cout<<n2<<"\t"<<setw(3)<<t2<<endl;
        cout<<n3<<"\t"<<setw(3)<<t3;
    }else if(t1<t3&&t3<t2){
        cout<<n1<<"\t"<<setw(3)<<t1<<endl;
        cout<<n3<<"\t"<<setw(3)<<t3<<endl;
        cout<<n2<<"\t"<<setw(3)<<t2;
    }else if(t2<t1&&t1<t3){
        cout<<n2<<"\t"<<setw(3)<<t2<<endl;
        cout<<n1<<"\t"<<setw(3)<<t1<<endl;
        cout<<n3<<"\t"<<setw(3)<<t3;
    }else if(t2<t3&&t3<t1){
        cout<<n2<<"\t"<<setw(3)<<t2<<endl;
        cout<<n3<<"\t"<<setw(3)<<t3<<endl;
        cout<<n1<<"\t"<<setw(3)<<t1;
    }else if(t3<t1&&t1<t2){
        cout<<n3<<"\t"<<setw(3)<<t3<<endl;
        cout<<n1<<"\t"<<setw(3)<<t1<<endl;
        cout<<n2<<"\t"<<setw(3)<<t2;
    }else{
        cout<<n3<<"\t"<<setw(3)<<t3<<endl;
        cout<<n2<<"\t"<<setw(3)<<t2<<endl;
        cout<<n1<<"\t"<<setw(3)<<t1;    
    }
    
    return 0;
}
    