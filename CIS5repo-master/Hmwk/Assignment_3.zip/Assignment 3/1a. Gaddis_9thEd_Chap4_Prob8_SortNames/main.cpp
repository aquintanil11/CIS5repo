/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream> //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main() 
{ 
    string n1,n2,n3;
    
    cout<<"Sorting Names"<< endl;
    cout<<"Input 3 names"<<endl;
    cin>>n1;
    cin>>n2;
    cin>>n3;
    
    if(n1<n2&&n2<n3){
        cout<<n1<<endl;
        cout<<n2<<endl;
        cout<<n3;
    }else if(n1<n3&&n3<n2){
        cout<<n1<<endl;
        cout<<n3<<endl;
        cout<<n2;
    }else if(n2<n1&&n1<n3){
        cout<<n2<<endl;
        cout<<n1<<endl;
        cout<<n3;
    }else if(n2<n3&&n3<n1){
        cout<<n2<<endl;
        cout<<n3<<endl;
        cout<<n1;
    }else if(n3<n1&&n1<n2){
        cout<<n3<<endl;
        cout<<n1<<endl;
        cout<<n2;
    }else{
        cout<<n3<<endl;
        cout<<n2<<endl;
        cout<<n1;
    }
    return 0;
}