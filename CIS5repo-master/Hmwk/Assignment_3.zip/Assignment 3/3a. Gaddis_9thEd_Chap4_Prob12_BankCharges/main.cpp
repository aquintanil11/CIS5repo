/* 
 * File:   main.cpp
 * Author: Antonio Quintanilla
 * Created on January 15, 2019, 5:55 PM
 * Purpose:  Bank Charges
 */

//System Libraries
#include <iostream> 
#include <iomanip>      //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main() 
{
    //Set the random number seed
    
    //Declare Variables
    float bbal,     // Beginning Balance
          cfee,     // Check Fee
          mfee,     // Monthly Fee
          lbal,     // Low Balance
          nbal;     // New Balance
    int nchk;       // Number of Checks
    
    //Initialize or input i.e. set variable values
    cout << "Monthly Bank Fees\n";
    cout << "Input Current Bank Balance and Number of Checks\n";
    cin >> bbal >> nchk;
    
    //Map inputs -> outputs
    if (bbal<400)
    { lbal=15; }
    
    if (nchk<20)
    { cfee=.10*nchk; }
    else if (20>=nchk && nchk<=39)
    { cfee=.08*nchk; }
    else if (40>=nchk && nchk<=59)
    { cfee=.06*nchk; }
    else cfee=.04*nchk;
    
    mfee=10;
    nbal=bbal-cfee-mfee-lbal;
    
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    
    //Display the outputs
    cout << "Balance     $" << setw(9) << bbal << endl;
    cout << "Check Fee   $" << setw(9) << cfee << endl;
    cout << "Monthly Fee $" << setw(9) << mfee << endl;
    cout << "Low Balance $" << setw(9) << lbal << endl;
    cout << "New Balance $" << setw(9) << nbal;
    
    //Exit stage right or left!
    return 0;
}