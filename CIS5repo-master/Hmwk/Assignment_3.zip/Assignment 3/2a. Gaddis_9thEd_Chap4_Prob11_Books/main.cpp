/* 
 * File:   main.cpp
 * Author: Antonio Quintanilla
 * Created on January 15, 2019, 5:51 PM
 * Purpose:  Displays the number of points awarded.
 */

//System Libraries
#include <iostream>  
#include <iomanip>   //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main() 
{
    //Set the random number seed
    
    //Declare Variables
    int bp,     // Books Purchased 
        pe;     // Points Earned
    //Initialize or input i.e. set variable values
    cout << "Book Worm Points\n";
    cout << "Input the number of books purchased this month.\n";
    //Map inputs -> outputs
    cin >> bp;
    
    if (bp==0)
    { pe=0; }
    else
    if (bp==1)
    { pe=5; }
    else
    if (bp==2)
    { pe=15; }
    else
    if (bp==3)
    { pe=30; }
    else
    if (bp>=4)
    { pe=60; }
    //Display the outputs
   
    cout << "Books purchased =" << setw(3) << bp << endl;
    
    cout << "Points earned   ="<< setw(3) << pe;
    //Exit stage right or left!
    return 0;
}