//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main() 
{
    //Set the random number seed
    
    //Declare Variables
    int mrc, //max room capacity
        crc, //current room capacity
        more, // number of people allowed if capacity is low
        less; //Too many people
        

    //Initialize or input i.e. set variable values
    cout << "Input the maximum room capacity and the number of people\n";
    cin >> mrc;
    cin >> crc;
    more = mrc-crc;
    less=crc-mrc;
    //Map inputs -> outputs
    if (mrc >= crc)
    {
        cout << "Meeting can be held.\n";
        cout << "Increase number of people by " << more << " will be allowed without violation.";
    }
    else
    {
        cout << "Meeting cannot be held.\n";
        cout << "Reduce number of people by " << less << " to avoid fire violation.";
    }
    //Display the outputs

    //Exit stage right or left!
    return 0;
}