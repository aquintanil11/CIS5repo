//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main() 
{
    //Set the random number seed
    
    //Declare Variables
    float pr,
        gp,
        hrs,
        ovt;
        
    //Initialize or input i.e. set variable values
    cout << "This program calculates the gross paycheck.\n";
    cout << "Input the pay rate in $'s/hr and the number of hours.\n";
    cin >> pr;
    cin >> hrs;
    
    //Map inputs -> outputs
    
    if (hrs > 40)
    {
        ovt= (hrs - 40)*pr;
        gp = (pr*hrs)+ovt;
    }
    else
    {
        gp=pr*hrs;
    }
    
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    //Display the outputs
    cout << "Paycheck = "<< "$"<< setw(7) << gp; 
    //Exit stage right or left!
    return 0;
}