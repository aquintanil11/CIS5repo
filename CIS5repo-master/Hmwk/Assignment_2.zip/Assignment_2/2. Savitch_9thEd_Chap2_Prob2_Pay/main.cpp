//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main() 
{
    //Set the random number seed
    
    //Declare Variables
    float ps,  //Previous Annual Salary
          PI, // Pay increase
          rp, //Retroactive pay
          nas, // New Annual Salary
          nms; // New Monthly Salary
    
    PI=.076f;
    
    //Initialize or input i.e. set variable values
    cout << "Input previous annual salary." << endl;
    cin >> ps;
    rp = (ps/2.)*PI;
    nas = ps + (PI*ps);
    nms = nas / 12;
    //Map inputs -> outputs
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    //Display the outputs
    cout << "Retroactive pay    " << "= " << "$" << setw(7) << rp << endl;
    cout << "New annual salary  " << "= " << "$" << setw(7) << nas << endl;
    cout << "New monthly salary" << " = " << "$" << setw(7) << nms;
    //Exit stage right or left!
    return 0;
}