//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main() 
{
    //Set the random number seed
    
    //Declare Variables
    int n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, sp, sn, sum, posi, negi;
    

    //Initialize or input i.e. set variable values
    cout << "Input 10 numbers, any order, positive or negative\n";
    cin >> n1 >> n2 >> n3 >> n4 >> n5 >> n6 >> n7 >> n8 >> n9 >> n10;
    //Map inputs -> outputs
      sum =n1+n2+n3+n4+n5+n6+n7+n8+n9+n10;
    //Display the outputs
   cout << "Negative sum =" << sn << endl;
   cout << "Positive sum =" << sp << endl;
   cout << "Total sum    =" << setw(4) << sum; 
    //Exit stage right or left!
    return 0;
}