//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float cpg = 4.53592e2f;
//Function Prototypes

//Execution Begins Here!
int main() 
{
    //Set the random number seed
   
    //Declare Variables
    float w, // Weight of dieter (lbs)
          sw, // Mass of sweetener neede to kill mouse.
          mm, // Mass of mouse.
          mc, // Mass of soda can
          conc; //soda concentration
    
    int cans; // Number of cans allowed
    
  
    //Initialize or input i.e. set variable values
    sw=5;
    mm=35;
    mc=350;
    conc=.001f;
    
    cout << "Program to calculate the limit of Soda Pop Consumption." << endl;
    cout << "Input the desired dieters weight in lbs." << endl;
     cin >> w;
    //Map inputs -> outputs
  cans=w*cpg*sw/(mm*mc*conc);
    //Display the outputs
    cout << "The maximum number of soda pop cans" << endl;
    cout << "which can be consumed is " << cans << " cans";
    //Exit stage right or left!
    return 0;
}