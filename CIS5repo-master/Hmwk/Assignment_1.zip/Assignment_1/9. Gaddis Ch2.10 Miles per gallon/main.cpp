/* 
 * Author: 
 * Date:
 * Purpose:
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Constants like PI, e, Gravity, Conversions, 2D array size only!

//Function Prototypes Here

//Program Execution Begins Here
int main() 
{
    //Set Random Number Seed Here
    
    //Declare all Variables Here
    float gallons;
    float distance;
    float MPG;
    //Input or initialize values Here
    cout << "Input number of gallons and distance traveled." << endl;
    cin >> gallons;
    cin >> distance;
    //Process/Calculations Here
    MPG = distance/gallons;
    //Output Located Here
    cout << "Your MPG is " << MPG;
    //Exit
    return 0;
}