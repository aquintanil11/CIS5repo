/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Antonio Quintanilla
 *
 * Created on January 14, 2019, 10:18 AM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
    int main() 
{
int x;
 int y;
 int total;

cout << "Input 2 integer numbers\n";
cin >> x;
cin >> y;

total = x + y;

cout << "The sum of " << x << "+" << y << "=" << total;
    return 0;
}

