/* 
 * Author: Antonio Quintanilla 
 * Date: January 14, 2019 11:04 am
 * Purpose: To find the average of 5 variables.
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Constants like PI, e, Gravity, Conversions, 2D array size only!

//Function Prototypes Here

//Program Execution Begins Here
int main() 
{
    //Set Random Number Seed Here
    
    //Declare all Variables Here
    double var1;
    double var2;
    double var3;
    double var4;
    double var5;
    double avg;
    //Input or initialize values Here
    cout << "Input 5 numbers." << endl;
    cin >> var1 >> var2 >> var3 >> var4 >> var5;
    
    //Process/Calculations Here
    avg = (var1+var2+var3+var4+var5)/5;
    //Output Located Here
cout << "The average is " << avg;
    //Exit
    return 0;
}