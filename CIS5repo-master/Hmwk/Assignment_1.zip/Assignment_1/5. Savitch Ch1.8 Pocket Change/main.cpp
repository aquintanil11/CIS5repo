#include <iostream>
using namespace std;

int main()
{
    int quarters;
    int dimes;
    int nickels;
    int total_cents;

    //Statement
    cout << "Enter the number of Quarters, Dimes and Nickels\n";
    cout << endl;
    //Input 
    cin >> quarters;
    cin >> dimes;
    cin >> nickels;
    
    total_cents = (quarters * 25) + (dimes * 10) + (nickels * 5);
    //Results
    cout << quarters << " Quarters " << "+ " << dimes << " Dimes" << " + " << nickels << " Nickels" << " = " << total_cents << " cents!"; 
     return 0;
}
    