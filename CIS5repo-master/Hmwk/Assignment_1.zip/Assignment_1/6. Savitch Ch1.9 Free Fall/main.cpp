#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    

double acceleration = 32; //feet per second
double time;

       cout << "Input the time in free-fall" << endl;
 
       cin >> time;
       
double timePow = pow(time, 2.0);
double distance = (acceleration * timePow)/2;

       cout << endl << "The distance = " << distance << " feet";

char letter;


       cin >> letter;

return (0);
}