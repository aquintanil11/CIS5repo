/* 
 * Author: Antonio Quintanilla 
 * Date: January 14, 2019 11:11 am
 * Purpose: To calculate the number of acres converted from square feet.
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Constants like PI, e, Gravity, Conversions, 2D array size only!

//Function Prototypes Here

//Program Execution Begins Here
int main() 
{
    //Set Random Number Seed Here
    
    //Declare all Variables Here
    float sqft;
    float acre;
    //Input or initialize values Here
    cout << "Input the number of square feet." << endl;
    cin >> sqft;
   
    //Process/Calculations Here
     acre=sqft/43560;
     
    //Output Located Here
    cout << "The number of acres is " << acre;
    //Exit
    return 0;
}