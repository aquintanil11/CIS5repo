

/* 
 * File:  Savitch Ch1.5 Product and Quotient of 2 Numbers
 * Author: Antonio Quintanilla
 *
 * Created on January 14, 2019, 10:28 AM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Set Random Number Seed Here
    
    //Declare all Variables Here
    int x;
    int y;
    int totalp;
    int totalq;
    
    //Input or initialize values Here
      cout << "Input 2 integer numbers." << endl;
      cout << endl;
    cin >> x;
    cin >> y;
    //Process/Calculations Here
    totalp = x * y;
    totalq = y / x;
    
    //Output Located Here
cout << "The product of " << x << "*" << y << " = " << totalp << endl;
cout << endl;
cout << "The quotient of " << y << "/" << x << " = " << totalq;
    //Exit
    return 0;
}

