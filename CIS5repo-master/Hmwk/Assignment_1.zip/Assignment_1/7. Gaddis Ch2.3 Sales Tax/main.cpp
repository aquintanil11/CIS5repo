/* 
 * Author: Antonio Quintanilla  
 * Date: January 14, 2019 11:01 am
 * Purpose:
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Constants like PI, e, Gravity, Conversions, 2D array size only!

//Function Prototypes Here

//Program Execution Begins Here
int main() 
{
    //Set Random Number Seed Here
    
    //Declare all Variables Here
    int price;
    double s_tax;
    double c_tax;
    double total_tax;
    //Input or initialize values Here
    cout << "Input price of purchase" << endl;
    cin >> price;
    s_tax= 0.04 * price;
     c_tax= 0.02 * price;
    //Process/Calculations Here
    total_tax = s_tax + c_tax;
    //Output Located Here
    cout << "The total sales tax is " << total_tax;
    //Exit
    return 0;
}