/* 
 * Author: Antonio Quintanilla
 * Date: January 14, 2019 10:34 am 
 * Purpose: To input a big C out of any chosen character.
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Constants like PI, e, Gravity, Conversions, 2D array size only!

//Function Prototypes Here

//Program Execution Begins Here
int main() 
{
    //Set Random Number Seed Here
    
    //Declare all Variables Here
    char X;
    //Input or initialize values Here
    cin >> X;
    //Process/Calculations Here
    
    //Output Located Here
    cout << "Input the character to make the Big C!\n";
    cout << endl;
cout << "    " << X <<  " " << X << " " << X << endl;
cout << "   " << X << "     " << X << endl;
cout <<"  " << X << endl;
cout <<"  " << X << endl;
cout <<"  " << X << endl;
cout <<"  " << X << endl;

cout << "   " <<  X << "     "  << X << endl;
cout << "    " << X << " " << X << " " << X << endl;

    //Exit
    return 0;
}